Gitian building
================

This file was moved to [the Taler Core documentation repository](https://github.com/taler-project/docs/blob/master/gitian-building.md) at [https://github.com/taler-project/docs](https://github.com/taler-project/docs).
